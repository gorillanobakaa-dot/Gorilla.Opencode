gorilla tar fixture
